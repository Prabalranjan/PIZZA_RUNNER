use pizza_runner;
show tables;
select * from runners;
select * from customer_orders;
select * from runner_orders;
select * from pizza_names;
select * from pizza_recipes;
select * from pizza_recipes_normal;
select * from pizza_toppings;
select * from worst_toppings;
select * from best_toppings;

-- Pizza Metrics
-- 1.How many pizzas were ordered? 

select count(order_id) as total_pizza_ordered
from customer_orders ;